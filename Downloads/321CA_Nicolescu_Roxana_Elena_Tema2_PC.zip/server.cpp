#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <string>
#include <cstring>
#include <sstream>

#define MAX_CLIENTS	5
#define BUFLEN 256

using namespace std;

struct user {
	std::string second_name;
	std::string first_name;
	std::string pin;
	std::string secret_password;
	double sold;
	bool is_logged;
	bool is_blocked;
	int nb_of_fails;

	user(string second_name, string first_name, string pin,
			string secret_password, double sold) :
			second_name(second_name), first_name(first_name), pin(pin),
			secret_password(secret_password), sold(sold), 
			is_logged(false), is_blocked(false), nb_of_fails(0) {}
};

void error(char *msg)
{
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[])
{
	int sockfd, newsockfd, portno, clilen;
    char buffer[BUFLEN];
    struct sockaddr_in serv_addr, cli_addr;
     
    int n, i, j;
     
    std::map<std::string, user> users;
    std::map<int, string> sessions;
 	std::map<int, string> errors;
 	std::map<int, int> clients;

    // deschidere users_file si errors
    std::ifstream inUsers, inErrors;
    inUsers.open(argv[2]);
    inErrors.open("errors");

    // punere in map clients fiecare client cu cheia cardId si restul informatiei la value
    int nbOfClients;
    inUsers >> nbOfClients;
    for (int i = 0; i < nbOfClients; ++i) {
     	std::string cardId;
     	std::string second_name;
		std::string first_name;
		std::string pin;
		std::string secret_password;
		double sold;

		inUsers >> second_name >> first_name >> cardId >> pin;
		inUsers >> secret_password >> sold;

		users.insert(pair<string, user>(cardId, 
						user(second_name, first_name, pin, secret_password, sold)));
    }
     
     // punere in map erorile
    for (int i = 1; i <= 10; ++i) {
     	string error;
    	getline(inErrors, error);
    	errors.insert(pair<int, string>(i, error));
    }

    // inchidere ambele fisiere
    inUsers.close();
    inErrors.close();
     
    fd_set read_fds;	//multimea de citire folosita in select()
    fd_set tmp_fds;	//multime folosita temporar 
    int fdmax;		//valoare maxima file descriptor din multimea read_fds

	 if (argc < 2) {
	     fprintf(stderr,"Usage : %s port\n", argv[0]);
	     exit(1);
	 }

	 
	 //golim multimea de descriptori de citire (read_fds) si multimea tmp_fds 
	 FD_ZERO(&read_fds);
	 FD_ZERO(&tmp_fds);
	 
	 sockfd = socket(AF_INET, SOCK_STREAM, 0);
	 if (sockfd < 0) 
	    error("ERROR opening socket");
	 
	 portno = atoi(argv[1]);

	 memset((char *) &serv_addr, 0, sizeof(serv_addr));
	 serv_addr.sin_family = AF_INET;
	 serv_addr.sin_addr.s_addr = INADDR_ANY;	// foloseste adresa IP a masinii
	 serv_addr.sin_port = htons(portno);
	 
	 if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(struct sockaddr)) < 0) 
	          error("ERROR on binding");
	 
	 listen(sockfd, MAX_CLIENTS);

	 //adaugam noul file descriptor (socketul pe care se asculta conexiuni) in multimea read_fds
	 FD_SET(sockfd, &read_fds);
	 fdmax = sockfd;


	 // main loop
	while (1) {
		tmp_fds = read_fds; 
		if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) 
			error("ERROR in select");

		for(i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &tmp_fds)) {
			
				if (i == sockfd) {
					// a venit ceva pe socketul inactiv(cel cu listen) = o noua conexiune
					// actiunea serverului: accept()
					clilen = sizeof(cli_addr);
					if ((newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, (socklen_t*) &clilen)) == -1) {
						error("ERROR in accept");
					} 
					else {
						//adaug noul socket intors de accept() la multimea descriptorilor de citire
						FD_SET(newsockfd, &read_fds);
						if (newsockfd > fdmax) { 
							fdmax = newsockfd;
						}

						// adaug in map clientul activ
						clients.insert(pair<int, int>(newsockfd, newsockfd));
					}
					printf("Noua conexiune de la %s, port %d, socket_client %d\n ", inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), newsockfd);
				}
					
				else if (i != 0) {

					// am primit date pe unul din socketii cu care vorbesc cu clientii
					//actiunea serverului: recv()
					 memset(buffer, 0 , BUFLEN);
					if ((n = recv(i, buffer, sizeof(buffer), 0)) <= 0) {
						
							error("ERROR in recv");
					} else { //recv intoarce >0
						printf ("Am primit de la clientul de pe socketul %d, mesajul: %s\n", i, buffer);
						
						char *command_type;
						command_type = strtok(buffer, "\n, ");
						cout << command_type << "\n";
						char buffer_trimis[BUFLEN];
						memset(buffer_trimis, 0, sizeof(buffer));
						strcpy(buffer_trimis, "ATM> ");

						if (!strcmp(command_type, "login")) {
							// este login, deci trebuie sa primeasca nr card si pin
							char *card;
							char *p;
							card = strtok(NULL, "\n, ");
							p = strtok(NULL, "\n, ");
							string card_id = (string) card;
							string pin = (string) p;
							map<string, user>::iterator it;
							
							// numar card prost
							if ((it = users.find(card_id)) == users.end()) {
								strcat(buffer_trimis, errors.find(4)->second.c_str());						
							} else if (it->second.is_logged) {
								
								// exista alta sesiune
								strcat(buffer_trimis, errors.find(2)->second.c_str());
							} else if (it->second.is_blocked) {
								strcat(buffer_trimis, errors.find(5)->second.c_str());
							} else if (it->second.pin.compare(pin)) {
								if (it->second.nb_of_fails == 2) {
									strcat(buffer_trimis, errors.find(5)->second.c_str());
									it->second.is_blocked = true;
								} else {
									strcat(buffer_trimis, errors.find(3)->second.c_str());
									it->second.nb_of_fails ++;
								}	
							} else {
								
								// deshidem frumos sesiune, yeeey
								it->second.nb_of_fails = 0;
								it->second.is_logged = true;
								strcat(buffer_trimis, "Welcome ");
								strcat(buffer_trimis, it->second.second_name.c_str());
								strcat(buffer_trimis, it->second.first_name.c_str());
								sessions.insert(pair<int,string>(i, card_id));
							}							

						} else if (!strcmp(command_type, "logout")) {
								
								// il deconecteaza
								strcat(buffer_trimis, "Deconectare de la bancomat");
								string cardulet = sessions.find(i)->second;
								users.find(cardulet)->second.is_logged = false;
								sessions.erase(i);		
						} else if (!strcmp(command_type, "listsold")) {
							string card_id = sessions.find(i)->second;
							double sold = users.find(card_id)->second.sold;
							strcat(buffer_trimis, std::to_string(sold).c_str());
						} else if (!strcmp(command_type, "getmoney")) {
							char* s = strtok(NULL, " ");
							double sum = atof(s);
							string card_id = sessions.find(i)->second;
							map<string, user>::iterator it = users.find(card_id);
							
							// daca suma nu e multiplu de 10
							if (((int) sum % 10) != 0) {
								strcat(buffer_trimis, errors.find(9)->second.c_str());
							} else if (sum > it->second.sold) {
									strcat(buffer_trimis, errors.find(8)->second.c_str());
								} else {
									it->second.sold -= sum;
									strcat(buffer_trimis, "Suma ");
									strcat(buffer_trimis, s);
									strcat(buffer_trimis, " retrasa cu succes");
								}
							
						} else if (!strcmp(command_type, "putmoney")) {

							//punem banuti
							char *s = strtok(NULL, " ");
							double sum = atof(s);
							string card_id = sessions.find(i)->second;
							map<string, user>::iterator it = users.find(card_id);
							it->second.sold += sum;
							strcat(buffer_trimis, "Suma depusa cu succes");

						} else if(!strcmp(command_type, "quit")) {
							FD_CLR(i, &read_fds);
							if (sessions.find(i) != sessions.end()) {
								string id = sessions.find(i)->second;
								users.find(id)->second.is_logged = false;
								sessions.erase(i);
							}

							clients.erase(i);
							break;
						}

						int n = send(i, buffer_trimis, strlen(buffer_trimis), 0);
	                	if (n < 0) 
	                    	 error("ERROR writing to socket");
					}
				} else if (i == 0){

					//ii dau quit
					memset(buffer, 0 , BUFLEN);

	                fgets(buffer, BUFLEN-1, stdin);
	                memset(buffer, 0 , BUFLEN);
	                strcpy(buffer, "bye, clients...i'm out :)\n");
	                for (map<int, int>::const_iterator it = clients.begin(); it != clients.end(); ++it) {
	                	int n = send(it->first, buffer, strlen(buffer), 0);
	                	if (n < 0) 
	                    	 error("ERROR writing to socket");
	                }
	                return 0;
				}
			}
		}
	 }
	
	close(sockfd);	
	return 0; 
}
