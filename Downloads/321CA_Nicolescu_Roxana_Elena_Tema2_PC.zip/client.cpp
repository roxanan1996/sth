#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <arpa/inet.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#define BUFLEN 256

void error(char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[]) {
    int session = 0;
    std::map<int, std::string> errors;

    // deschidere fisier unde am erorile
    std::ifstream inErrors;
    inErrors.open("errors");

    // citire erori si punerein map
    for (int i = 1; i <= 10; ++i) {
        std::string error;
        getline(inErrors, error);
        errors.insert(std::pair<int, std::string>(i, error));
    }

    // inchidere fisier
    inErrors.close();
    
    // deschidere fisier pid.log
    char name_file_log[100];
    sprintf(name_file_log, "%ld .log", (long) getpid());

    FILE *log = fopen(name_file_log, "a+");
    if (log == NULL) {
        fprintf(stderr, "ERROR: Can't open file %s", name_file_log);
        return -1;
    }

    // tcp multiplexare
    int sockfd, n,i,fdmax;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    fd_set read_fds,tmp_fds;

    //golim multimea de descriptori de citire (read_fds) si multimea tmp_fds 
     FD_ZERO(&read_fds);
     FD_ZERO(&tmp_fds);

    char buffer[BUFLEN];
    if (argc < 3) {
       fprintf(stderr,"Usage %s server_address server_port\n", argv[0]);
       exit(0);
    }  
    
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[2]));
    inet_aton(argv[1], &serv_addr.sin_addr);
    
    FD_SET(0,&read_fds);
    
    if (connect(sockfd,(struct sockaddr*) &serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");

    //adaugam noul file descriptor (socketul pe care se asculta conexiuni) in multimea read_fds
    FD_SET(sockfd, &read_fds);
    fdmax = sockfd;
    
    while(1) {
        tmp_fds = read_fds; 
        if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) 
            error("ERROR in select");
    
        for(i = 0; i <= fdmax; i++) {
            if (FD_ISSET(i, &tmp_fds)) {

                //citesc de la tastatura
                if(i==0) {
                    memset(buffer, 0 , BUFLEN);

                    fgets(buffer, BUFLEN-1, stdin);
                    char buffer1[BUFLEN];
                    strcpy(buffer1, buffer);

                    //trimitere mesaj la server
                    
                    char* command_type = strtok(buffer1, "\n, ");
                    
                    // verific daca exista un alt user de pe clientul asta
                    if (!strcmp(command_type, "login")) {
                        if (session == 0) {
                            // e ok, deci trimit la server
                            n = send(sockfd, buffer, strlen(buffer), 0);
                            if (n < 0) 
                                error("ERROR writing to socket");
                        } else {
                            // nu e ok, afisez eroare
                            memset(buffer, 0 , BUFLEN);
                            strcpy(buffer, errors.find(2)->second.c_str());
                            fputs(buffer, stdout);
                            printf("\n");
                            fputs(buffer, log);

                        }
                    } else if (!strcmp(command_type, "logout")) {
                        if (session == 0) {
                            memset(buffer, 0 , BUFLEN);
                            strcpy(buffer, errors.find(1)->second.c_str());
                            fputs(buffer, stdout);
                            printf("\n");
                            fputs(buffer, log);
                        } else {
                            n = send(sockfd, buffer, strlen(buffer), 0);
                            if (n < 0) 
                                error("ERROR writing to socket");
                        }
                    } else {
                        n = send(sockfd, buffer, strlen(buffer), 0);
                        if (n < 0) 
                             error("ERROR writing to socket");
                        } 
                } else {

                    // primesc mesaj de la server, deci afisez si pun in fisierul .log
                    memset(buffer, 0 , BUFLEN);

                    n = recv(sockfd, buffer, sizeof(buffer), 0);
                    if (n < 0) 
                        error("ERROR reading from socket");
                    
                    // punere in fisier
                    fputs(buffer, log);

                    // afisare
                    fputs(buffer,stdout);

                    // verificare daca s a deschis o sesiune noua, sau s a inchis cea existenta
                    char *ceva = strtok(buffer, "\n, ");
                    char *received = strtok(NULL, "\n, ");

                    if (!strcmp(received, "Welcome")) {
                        session = 1;
                    } else if(!strcmp(received, "Deconectare")) {
                        session = 0;
                    }

                    printf("\n");
                }
            }
        }
    }

    //inchidere fisier .log
    fclose(log);
    return 0;
}