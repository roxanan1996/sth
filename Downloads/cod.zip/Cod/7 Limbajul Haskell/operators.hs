add4    = (+)

result1 = (+) 1 2     -- operator ca functie
result2 = 1 `add4` 2  -- functie ca operator

inc1    = (1 +)       -- sectiuni
inc2    = (+ 1)
inc3    = (1 `add4`)
inc4    = (`add4` 1)